# Kredily HRMS – QA Assessment

This repository contains the QA assessment artifacts for the Kredily HRMS Android APK.

## Contents
- `Manual-Testing/` – 20 functional test cases and execution summary
- `Bug-Reports/` – defect reporting template and evidence
- `Mobile-Automation/` – Appium automation structure
- `API-Testing/` – API testing documentation and Postman deliverable location
- `AI-Assisted-QA/` – AI usage documentation
- `Final-Report/` – final QA summary
- `Screenshots/` – execution evidence
- `Videos/` – execution evidence

## Tools
Java, Appium, TestNG, Maven, Postman, Git/GitHub, ChatGPT.

## Important
Execution results, bugs, screenshots/videos, actual mobile locators, and API endpoints must be populated from the supplied APK. No unverified result is presented as an executed finding.
