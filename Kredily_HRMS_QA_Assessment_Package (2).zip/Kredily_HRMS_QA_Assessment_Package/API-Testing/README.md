# API Testing – Kredily HRMS

The assessment requires at least 3 accessible APIs with positive and negative scenarios.

## Candidate API areas
- Authentication / Login
- Attendance
- Leave

These are testing areas, not confirmed API endpoints. Actual endpoints, methods, headers, authentication and request/response schemas must be captured from the supplied application or API documentation.

## Postman deliverable
Export the final Postman collection as:
`Kredily_API_Testing_Collection.json`

## Test coverage
For each accessible API:
- Positive request
- Missing/invalid required field
- Invalid authentication or authorization where applicable
- Response status code
- Response body/schema
- Error message
- Data consistency
