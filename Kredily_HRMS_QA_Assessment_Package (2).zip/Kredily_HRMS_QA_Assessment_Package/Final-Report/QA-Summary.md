# Kredily HRMS – QA Assessment

## Objective
Evaluate the Kredily HRMS Android application through manual functional testing, defect reporting, mobile automation, API testing, and AI-assisted QA.

## Scope
- 20 manual test cases
- Positive, negative and edge-case coverage
- Genuine defect identification
- 5 mobile automation journeys
- At least 3 accessible APIs
- AI-assisted QA activity

## Deliverables
- Manual test cases and execution: `Manual-Testing/`
- Bug reports/evidence: `Bug-Reports/`
- Mobile automation: `Mobile-Automation/`
- API testing: `API-Testing/`
- AI-assisted QA: `AI-Assisted-QA/`
- Screenshots/videos: `Screenshots/`, `Videos/`

## Execution Results
To be updated after actual execution of the APK.

## Defects
Only genuine, reproducible defects observed during execution should be listed here.

## Automation
To be updated with actual Appium execution results and report.

## API Testing
To be updated with actual accessible API endpoints and Postman results.

## Conclusion
The final conclusion should be based on executed evidence, not assumptions.
