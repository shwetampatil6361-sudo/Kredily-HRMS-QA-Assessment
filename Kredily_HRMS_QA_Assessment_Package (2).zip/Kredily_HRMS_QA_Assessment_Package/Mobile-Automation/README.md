# Mobile Automation – Kredily HRMS

## Intended Stack
- Java
- Appium
- TestNG
- Maven
- Android emulator or real Android device

## Target Journeys
1. Valid Login
2. Invalid Login
3. Dashboard Validation
4. Attendance / Check-in
5. Leave workflow

## Important
The actual resource IDs/content descriptions/XPaths must be captured from the supplied APK using Appium Inspector or Android UI inspection. Do not use guessed locators.

## Execution
1. Install Java and Maven.
2. Install Appium and Android SDK.
3. Start an Android emulator or connect a test device.
4. Start the Appium server.
5. Install the supplied APK.
6. Update desired capabilities and actual locators.
7. Run `mvn test`.
8. Save the execution report under `execution-report/`.

## Current Status
Automation code and execution results must be completed after inspecting and executing the actual APK.
