# AI-Assisted QA Documentation

## AI Tool
ChatGPT

## Activity
Generation of an initial set of positive, negative, and edge-case test scenarios for the Kredily HRMS mobile application.

## Prompt Used
Generate positive, negative, and edge-case test scenarios for a mobile HRMS application covering login, dashboard, attendance/check-in, leave management, profile, notifications, and logout. Keep the scenarios suitable for manual execution and identify assumptions that must be validated against the actual application.

## AI-Generated Output
The AI-generated scenarios were used only as an initial brainstorming aid. The final test cases were reviewed against the actual application and modified to remove non-applicable assumptions and add application-specific checks.

## Human Validation / Changes
- Verified whether each suggested module actually exists in the supplied APK.
- Removed scenarios that were not applicable.
- Added negative and edge cases discovered during exploratory testing.
- Executed the final scenarios manually.

## Evidence
Add screenshots or execution references here after actual execution.
